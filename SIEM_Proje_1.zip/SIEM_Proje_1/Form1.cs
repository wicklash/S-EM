﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices.WindowsRuntime;

namespace SIEM_Proje_1
{

    public partial class Form1 : Form
    {
        private List<LogEntry> logEntries;
        private int currentIndex = 0;
        private int count = 0;
        public Form1()
        {
            InitializeComponent();
            LoadLogs();
        }
        private void LoadLogs()
        {
            
            var parser = new LogParser();
            logEntries = parser.ReadLogEntries("log_source.txt");
        }

        private int countEventId(int eventId)
        {
            
            if (logEntries[currentIndex].EventID == eventId)
            {
                count++;
                return count;
            }
            else return 0;

        }
        private void State()
        {
            if(0<=count && count<=2) {
                label2.Text = "HATA1";
            }
            else if (2<=count && count<=5)
            {
                label2.Text = "HATA2";
            }
            else
            {
                label2.Text = "HATA3";
            }
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (logEntries == null || logEntries.Count == 0)
            {
                MessageBox.Show("Log entries are not loaded.");
                return;
            }

            if (currentIndex < logEntries.Count)
            {
                var entry = logEntries[currentIndex];
                dataGridView1.Rows.Clear();
                dataGridView1.Rows.Add(entry.Timestamp, entry.IP, entry.UserName, entry.EventID, entry.Message, entry.Machine);
                label1.Text = Convert.ToString( countEventId(3));
                State();
                currentIndex++;  
            }

            else
            {
                MessageBox.Show("No more logs to display.");
                currentIndex = 0;  
            }
        }

    }
    public class LogEntry
    {
        public DateTime Timestamp { get; set; }
        public string IP { get; set; }
        public string UserName { get; set; }
        public int EventID { get; set; }
        public string Message { get; set; }
        public string Machine { get; set; }
    }
    public class LogParser
    {
        public List<LogEntry> ReadLogEntries(string filePath)
        {
            var logEntries = new List<LogEntry>();

            foreach (var line in File.ReadAllLines(filePath))
            {
                var parts = line.Split(new[] { ", " }, StringSplitOptions.None);

                var logEntry = new LogEntry
                {
                    Timestamp = DateTime.ParseExact(parts[0].Substring(11), "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                    IP = parts[1].Substring(4),
                    UserName = parts[2].Substring(10),
                    EventID = int.Parse(parts[3].Substring(9)),
                    Message = parts[4].Substring(8),
                    Machine = parts[5].Substring(9)
                };

                logEntries.Add(logEntry);
            }

            return logEntries;
        }
    }
}
